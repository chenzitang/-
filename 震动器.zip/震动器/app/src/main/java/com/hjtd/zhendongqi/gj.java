package com.hjtd.zhendongqi;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;
import android.content.*;

public class gj extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
        setContentView(R.layout.gj);
		
		//控件ID获取
		Button zd=findViewById(R.id.zd);
		Button wx=findViewById(R.id.wx);
		Button stop=findViewById(R.id.stop);
		
		//点击事件
		zd.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					
					//获取编辑框ID
					EditText 内容 =findViewById(R.id.yid);
					EditText 内容1 =findViewById(R.id.yiz);
					//分割线
					EditText 内容2 =findViewById(R.id.erd);
					EditText 内容3 =findViewById(R.id.erz);
					
					//获取编辑框内容
					final int nr=Integer.parseInt(内容.getText().toString());
					final int nr1=Integer.parseInt(内容1.getText().toString());
					final int nr2=Integer.parseInt(内容2.getText().toString());
					final int nr3=Integer.parseInt(内容3.getText().toString());

					//开启震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { nr, nr1, nr2, nr3 }, -1);

				}
			});
		
		wx.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{

					//获取编辑框ID
					EditText 内容 =findViewById(R.id.yid);
					EditText 内容1 =findViewById(R.id.yiz);
					//分割线
					EditText 内容2 =findViewById(R.id.erd);
					EditText 内容3 =findViewById(R.id.erz);

					//获取编辑框内容
					final int nr=Integer.parseInt(内容.getText().toString());
					final int nr1=Integer.parseInt(内容1.getText().toString());
					final int nr2=Integer.parseInt(内容2.getText().toString());
					final int nr3=Integer.parseInt(内容3.getText().toString());

					//开启震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { nr, nr1, nr2, nr3 }, 0);

				}
			});
			
		stop.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//提示
					String i = "一键关闭成功";
					Toast.makeText(gj.this, i, Toast.LENGTH_SHORT).show();

					/**
					 *
					 *滑稽树上滑稽果
					 *滑稽树下你和我
					 *
					 */


					//再次使用震动来抵消之前的震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { 0, 100, 0, 0 }, -1);

				}
			});
		
		}
		
	}
		
