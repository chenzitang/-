package com.hjtd.zhendongqi;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
        setContentView(R.layout.main);

		//Toast.makeText(this, "加载中……", Toast.LENGTH_LONG).show();

		//Handler延时执行
		new Handler().postDelayed(new Runnable() {
				public void run() 
				{
					/**
					 *本软件由滑稽团队制作
					 *二改请注明
					 *仅学习使用，请勿倒卖！
					 *本软件已免费开源
					 */
					//跳转界面
					Intent i = new Intent(MainActivity.this, one.class);
					startActivity(i);

					//摧毁界面
					MainActivity.this.finish();
				}
			}, 3000); //3秒后执行


	}}
