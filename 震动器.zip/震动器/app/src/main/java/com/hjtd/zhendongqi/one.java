/**
 *滑稽团队制作
 *作者QQ：2810555422 
 *未经许可，禁止二改
 *二改请注明
 */
package com.hjtd.zhendongqi;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;
import android.content.*;

public class one extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
        setContentView(R.layout.one);

		//滑稽树上滑稽果
		/**发送一条通知栏消息*/
		NotificationManager manager=(NotificationManager)one.this.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification.Builder builder=new Notification.Builder(one.this);
		/*设置图标*/
		builder.setSmallIcon(android.R.drawable.sym_action_chat);
		builder.setContentTitle("系统提示");
		builder.setContentText("本软件由滑稽团队制作！");
		//显示预览的滚动信息
		builder.setTicker("来信息啦!");
		Notification notification=builder.build();
		//发送通知，第一个参数设置通知ID
		manager.notify(1, notification);

		//控件ID获取
		Button paly=findViewById(R.id.paly);
		Button paly1=findViewById(R.id.paly1);
		Button paly2=findViewById(R.id.paly2);
		Button paly3=findViewById(R.id.paly3);
		Button gj=findViewById(R.id.gj);
		Button no=findViewById(R.id.no);




		//点击事件
		paly.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//提示
					String i = "震动3s";
					Toast.makeText(one.this, i, Toast.LENGTH_SHORT).show();

					//开启震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { 0, 0, 0, 3000 }, -1);

				}
			});

		paly1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//提示
					String i = "震动10s";
					Toast.makeText(one.this, i, Toast.LENGTH_SHORT).show();

					//开启震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { 0, 0, 0, 10000 }, -1);

				}
			});

		paly2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//提示
					String i = "震动1s，停顿1s";
					Toast.makeText(one.this, i, Toast.LENGTH_SHORT).show();

					//开启震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { 100, 100, 100, 100 }, 0);

				}
			});

		paly3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//提示
					String i = "自定义震动";
					Toast.makeText(one.this, i, Toast.LENGTH_SHORT).show();

					//获取编辑框ID
					EditText 内容 =findViewById(R.id.nr);

					//获取编辑框内容
					final int nr=Integer.parseInt(内容.getText().toString());

					//开启震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { 0, 0, 0, nr }, -1);

				}
			});

		gj.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//跳转
					Intent i = new Intent(one.this, gj.class);
					startActivity(i);
				}
			});

		no.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//提示
					String i = "一键关闭成功";
					Toast.makeText(one.this, i, Toast.LENGTH_SHORT).show();

					/**
					 *当你看见这条消息时
					 *请你一定要认真看完它
					 *恐怕你会有所疑问：为什么关闭震动还是震动？
					 *这的确是个问题，因为我无意中发现：在震动中，这次震动，就能抵消震动
					 *我不知道你能不能明白这一点
					 */


					//再次使用震动来抵消之前的震动
					Vibrator mVibrator = (Vibrator) getApplication().
						getSystemService(Service.VIBRATOR_SERVICE);
					mVibrator.vibrate(new long[] { 0, 100, 0, 0 }, -1);

				}
			});


	}

	private void setOnClickListener(Object onClick)
	{
		// TODO: Implement this method
	}
	//再按一次退出

	static boolean isExit; 

	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_BACK)
		{
			if (!isExit)
			{
				isExit = true;
				Toast.makeText(getApplicationContext(), "再按一次退出程序",
							   Toast.LENGTH_SHORT).show();
				new Thread(new Runnable() {
						@Override
						public void run()
						{
							try
							{
								Thread.sleep(3000);
								isExit = false;
							}
							catch (InterruptedException e)
							{
								e.printStackTrace();
							}
						}
					}).start();
			}
			else
			{
				finish();
			}
			return false;
		}
		else
		{
			return super.onKeyDown(keyCode, event);
		}

	}}
